#importing dictionaries
import random
from logo import logo

#showing the sweet ascii art
print(logo)

#creating the 1 to 100 list to pull from 
the_answer = []
for i in range(1, 101):
  i = the_answer.append(i)

#defining the variables
game_is_live = True
user_lives = 0
answer = random.choice(the_answer)

#definig the hint functionality
def hint():
  global player_answer
  if player_answer > answer:
    print('Too high.')
  if player_answer < answer: 
    print('Too low.')

#Welcome the player
print('Welcome to the number guessing game')

#Choosing the difficulty
#I wanted to do this in a function but i couldn't get it to run correctly
difficulty = input('Would you like the hard version or the easy version?').lower()
if difficulty == 'easy':
  user_lives += 20
if difficulty == 'hard': 
  user_lives += 10

#initial player input
player_answer = int(input('Guess a number between 1 and 100: '))

#debug code
#print(user_lives)
#print(answer)

#While loop playing the actual game
while game_is_live == True:
  if player_answer == answer:
    print('You win!')
    game_is_live = False
  elif player_answer != answer:
    print(f'you guessed {player_answer}, try again.')
    hint()
    user_lives -= 1
    print(f'You have {user_lives} left')
    player_answer = int(input('Next Guess'))
  else: 
    print('you lose')
    game_is_live = False
